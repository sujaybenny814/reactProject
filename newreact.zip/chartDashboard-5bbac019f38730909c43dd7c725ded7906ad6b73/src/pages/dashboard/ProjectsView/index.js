import React from "react";
import Authorize from 'components/LayoutComponents/Authorize'
// import { Pie } from 'react-chartjs-2'
import { CircularProgressbar,buildStyles } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';
import ChartistGraph from 'react-chartist'
import ChartistTooltip from 'chartist-plugin-tooltips-updated'

class ProjectsView extends React.Component{

    render(){
        const stackedBarData = {
            labels: ['Planned', 'Actual'],
            series: [
              [4e5,4e6],
              [7e5, 4e5],
              [1e5, 2e5],
            ],
            style: {
              width: '300px'
          }
          }
          const stackedBarOptions = {
            stackBars: !0,
            axisY: {
              labelInterpolationFnc(value) {
                return `${value / 1e3}k`
              },
             
            },
            plugins: [ChartistTooltip({ anchorToPoint: false, appendToBody: true, seriesName: false })],
          }

    return ( 
      <Authorize roles={['admin']} redirect to="/dashboard/beta">

        <div className="row">
          <div className="col-xl-9">
            <div className="card">
              <div className="mt-3" style={{marginLeft:"3%"}}>
                 WHATSAPP SELF-SERVICE CHATBOT
              </div>
              <div style={{marginLeft:"3%",fontFamily:""}}>
                 Vendor:ABC Engineering Private Limited.
              </div>
              <div className='row mt-2'>
                <div className="col-md-3">
                  <div className="mb-5 mt-2">
                    <div style={{marginLeft: "3%"}}> Planning 
                    </div>
                    <div className="col-md-12">
                      <CircularProgressbar className="col-md-12" styles={buildStyles({ pathColor: `rgba(62, 152, 10, ${100 / 100})`,})} value={100} text={`${100}%`} />
                    </div>
                  </div>  
                </div>
                <div className="col-md-3">
                  <div className="mb-5 mt-2">
                    <div style={{marginLeft: "3%"}}> Design 
                    </div>
                    <div className="col-md-12">
                      <CircularProgressbar className="col-md-12" styles={buildStyles({ pathColor: `rgba(62, 152, 10, ${100 / 100})`,})} value={100} text={`${100}%`} />
                    </div>
                  </div>  
                </div>
                <div className="col-md-3">
                  <div className="mb-5 mt-2">
                    <div style={{marginLeft: "3%"}}> Development 
                    </div>
                    <div className="col-md-12">
                      <CircularProgressbar className="col-md-12" styles={buildStyles({ pathColor: `rgba(11, 7, 110, ${50 / 100})`,})} value={50} text={`${50}%`} />
                    </div>
                  </div>  
                </div>
                <div className="col-md-3">
                  <div className="mb-5 mt-2">
                    <div style={{marginLeft: "3%"}}> Testing 
                    </div>
                    <div className="col-md-12">
                      <CircularProgressbar className="col-md-12" styles={buildStyles({ pathColor: `rgba(11, 7, 110, ${10 / 100})`,})} value={10} text={`${10}%`} />
                    </div>
                  </div>  
                </div>
              </div>            
            </div>
          </div>
          <div className="col-xl-3">
            <div className="card" style={{backgroundColor:"green",marginBottom: "-3%" ,opacity:'5'}}>
              <h2 className='mt-5' style={{marginLeft:"22%"}}> Estimated </h2>
              <h2 style={{marginLeft:"17%"}}>Launch Date </h2>
              <div className="mt-5">
                <h5 style={{marginLeft:"36%"}}>107 Days</h5>
              </div>
              <div className="mt-5" style={{marginLeft:"34%",marginBottom:"9%"}}>
                May 15 2020
              </div>
            </div>
          </div> 
        </div>
        <div className="row">
          <div className="col-xl-6">
            <div className="card">
              <div className="mt-3" style={{marginLeft: "5%"}}>PROJECT SPEND
              </div>    
              <div className="row mt-2">
                <div className="col-xl-6">
                  <div className="mb-5">
                    <ChartistGraph
                      className="height-200"
                      data={stackedBarData}
                      options={stackedBarOptions}
                      type="Bar"
                    />
                  </div>
                </div>
                <div className="col-xl-6">
                  <div className="row">
                    <div className="col-xl-6">
                     Total Budget
                    </div>
                    <div className="col-xl-6">
                      <div className='row' style={{marginLeft:"1%"}}>
                      $52,000
                      </div>     
                    </div>
                  </div>
                  <div className="row mt-5">
                    <div className="col-xl-6">
                     Remaining
                    </div>
                    <div className="col-xl-6">
                      <div className='row' style={{marginLeft:"7%"}}>
                    $8,370
                      </div>             
                    </div>
                  </div>
                  <div className="row mt-5">
                    <div className="col-xl-4">
                     Currently
                    </div>
                    <div className="col-xl-8">
                      <div className='row' style={{marginLeft:"42%"}}>
                     8.1%
                      </div>
                      <div className='row' style={{marginLeft:"14%" ,color:"red"}}>
                      Over Target
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-xl-6">
            <div className="card" style={{paddingBottom:"4%"}}>
              <div className="mt-3" style={{marginLeft:"5%"}}>FEATURES
              </div>    
              <div className='row mt-3'>
                <div className="col-xl-12" style={{marginLeft:"5%"}}>
                  <div className="row">
                    <div className="col-xl-3" style={{marginLeft:"4%"}}>
                      <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" />
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"-8%"}}>Task
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"-4%"}}>Contact Person
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"4%"}}>Status
                    </div>
                  </div>
              
                </div>
              </div>
              <div className='row mt-4'>
                <div className="col-xl-12" style={{marginLeft:"5%"}}>
                  <div className="row">
                    <div className="col-xl-3" style={{marginLeft:"4%"}}>
                      <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" />
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"-10%"}}>Customer Onboarding
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"1%"}}>Shekhar
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"-1%"}}>Completed
                    </div>
                  </div>
              
                </div>
              </div>
              <div className='row mt-4'>
                <div className="col-xl-12" style={{marginLeft:"5%"}}>
                  <div className="row">
                    <div className="col-xl-3" style={{marginLeft:"4%"}}>
                      <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" />
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"-10%"}}>Product Catalogue
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"1%"}}>Eugeina
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"-1%"}}>Completed
                    </div>
                  </div>
              
                </div>
              </div>
              <div className='row mt-4'>
                <div className="col-xl-12" style={{marginLeft:"5%"}}>
                  <div className="row">
                    <div className="col-xl-3" style={{marginLeft:"4%"}}>
                      <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" />
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"-10%"}}>Contract Generation
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"1%"}}>Shekhar
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"-1%"}}>In Progress
                    </div>
                  </div>
              
                </div>
              </div>
              <div className='row mt-4'>
                <div className="col-xl-12" style={{marginLeft:"5%"}}>
                  <div className="row">
                    <div className="col-xl-3" style={{marginLeft:"4%"}}>
                      <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" />
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"-10%"}}>ESN Integration
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"1%"}}>Nijesh
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"-1%"}}>Not Started
                    </div>
                  </div>
              
                </div>
              </div>
              {/* <div className='row mt-4'>
                <div className="col-xl-12" style={{marginLeft:"5%"}}>
                  <div className="row">
                    <div className="col-xl-3" style={{marginLeft:"4%"}}>
                      <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" />
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"-10%"}}>ESN Integration
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"-1%"}}>Nijesh
                    </div>
                    <div className="col-xl-3" style={{marginLeft:"-1%"}}>Not Started
                    </div>
                  </div>
              
                </div>
              </div> */}
            </div>
          </div>
        </div>
      </Authorize>
        )
    }


}

export default ProjectsView