import React from "react"
import Authorize from 'components/LayoutComponents/Authorize'
import ChartistGraph from 'react-chartist'
import ChartistTooltip from 'chartist-plugin-tooltips-updated'

class FunctionalCostBenefit extends React.Component {
    render() {
        const stackedBarData = {
            labels: ['Planned', 'Actual'],
            series: [
                [4e5],
                // [7e5, 4e5],
                // [1e5, 2e5],
            ],
            style: {
                width: '300px'
            }
        }
      const stackedBarOptions = {
            stackBars: !0,
            axisY: {
                labelInterpolationFnc(value) {
                    return `${value / 1e3}k`
                },

            },
            plugins: [ChartistTooltip({ anchorToPoint: false, appendToBody: true, seriesName: false })],
        }
        return (
          <Authorize roles={['admin']} redirect to="/dashboard/beta">
            <h5 style={{ fontFamily: "serif" }}> SALES
            </h5>
            <div className="row">
              <div className="col-xl-4">
                <div className="card">
                  <div className="card card" style={{ padding: '5%', paddingTop: '5%' }}>
                    <h5 className="text-black">
                      <strong>Program A</strong>
                      <span className="dot float-right" style={{ height: '25px', width: '25px', backgroundColor: " #00FF00", borderRadius: '50%', color: "#00FF00", display: "inline-block" }}>a</span>
                    </h5>
                    <div className="mb-5">
                      <ChartistGraph
                        className="height-150"
                        data={stackedBarData}
                        options={stackedBarOptions}
                        type="Bar"
                      />
                    </div>
                    <div className='row'>
                      <div className="col-xl-4" style={{ fontFamily: "serif", fontSize: "15px" }}>NPS Score
                      </div>
                      <div className="col-xl-3 offset-xl-5">
                        <div style={{ paddingLeft: "34%", color: "green" }}>18%
                        </div>
                      </div>
                    </div>
                    <div className='row'>
                      <div className="col-xl-6" style={{ fontFamily: "serif", fontSize: "15px" }}>Revenue Uplift
                      </div>
                      <div className="col-xl-3 offset-xl-3">
                        <div style={{ paddingLeft: "46%", color: "green" }}>9%
                        </div>
                      </div>
                    </div>
                    <div className='row'>
                      <div className="col-xl-8" style={{ fontFamily: "serif", fontSize: "15px" }}>Cost Saving
                      </div>
                      <div className="col-xl-4">
                        <div style={{ paddingLeft: "17%", color: "green" }}>170000$
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-4">
                <div className="card">
                  <div className="card card" style={{ padding: '5%', paddingTop: '5%' }}>
                    <h5 className="text-black">
                      <strong>Program B</strong>
                      <span className="dot float-right" style={{ height: '25px', width: '25px', backgroundColor: "yellow", borderRadius: '50%', color: "yellow", display: "inline-block" }}>a</span>
                    </h5>
                    <div className="mb-5">
                      <ChartistGraph
                        className="height-150"
                        data={stackedBarData}
                        options={stackedBarOptions}
                        type="Bar"
                      />
                    </div>
                    <div className='row'>
                      <div className="col-xl-4" style={{ fontFamily: "serif", fontSize: "15px" }}>NPS Score
                      </div>
                      <div className="col-xl-3 offset-xl-5">
                        <div style={{ paddingLeft: "34%", color: "green" }}>18%
                        </div>
                      </div>
                    </div>
                    <div className='row'>
                      <div className="col-xl-6" style={{ fontFamily: "serif", fontSize: "15px" }}>Revenue Uplift
                      </div>
                      <div className="col-xl-3 offset-xl-3">
                        <div style={{ paddingLeft: "46%", color: "green" }}>9%
                        </div>
                      </div>
                    </div>
                    <div className='row'>
                      <div className="col-xl-8" style={{ fontFamily: "serif", fontSize: "15px" }}>Cost Saving
                      </div>
                      <div className="col-xl-4">
                        <div style={{ paddingLeft: "36%", color: "green" }}>2300$
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-4">
                <div className="card">
                  <div className="card card" style={{ padding: '5%', paddingTop: '5%' }}>
                    <h5 className="text-black">
                      <strong>Program C</strong>
                      <span className="dot float-right" style={{ height: '25px', width: '25px', backgroundColor: "red", borderRadius: '50%', color: "red", display: "inline-block" }}>a</span>
                    </h5>
                    <div className="mb-5">
                      <ChartistGraph
                        className="height-150"
                        data={stackedBarData}
                        options={stackedBarOptions}
                        type="Bar"
                      />
                    </div>
                    <div className='row'>
                      <div className="col-xl-4" style={{ fontFamily: "serif", fontSize: "15px" }}>NPS Score
                      </div>
                      <div className="col-xl-3 offset-xl-5">
                        <div style={{ paddingLeft: "22%", color: "red" }}>-10%
                        </div>
                      </div>
                    </div>
                    <div className='row'>
                      <div className="col-xl-6" style={{ fontFamily: "serif", fontSize: "15px" }}>Revenue Uplift
                      </div>
                      <div className="col-xl-3 offset-xl-3">
                        <div style={{ paddingLeft: "25%", color: "green" }}>0.1%
                        </div>
                      </div>
                    </div>
                    <div className='row'>
                      <div className="col-xl-8" style={{ fontFamily: "serif", fontSize: "15px" }}>Cost Saving
                      </div>
                      <div className="col-xl-4">
                        <div style={{ paddingLeft: "25%", color: "red" }}>-40000$
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <h5 style={{ fontFamily: "serif" }}> B2B
            </h5>
            <div className="row">
              <div className="col-xl-4">
                <div className="card">
                  <div className="card card" style={{ padding: '5%', paddingTop: '5%' }}>
                    <h5 className="text-black">
                      <strong>Program D</strong>
                      <span className="dot float-right" style={{ height: '25px', width: '25px', backgroundColor: "red", borderRadius: '50%', color: "red", display: "inline-block" }}>a</span>
                    </h5>
                    <div className="mb-5">
                      <ChartistGraph
                        className="height-150"
                        data={stackedBarData}
                        options={stackedBarOptions}
                        type="Bar"
                      />
                    </div>
                    <div className='row'>
                      <div className="col-xl-4" style={{ fontFamily: "serif", fontSize: "15px" }}>NPS Score
                      </div>
                      <div className="col-xl-3 offset-xl-5">
                        <div style={{ paddingLeft: "34%", color: "red" }}>-4%
                        </div>
                      </div>
                    </div>
                    <div className='row'>
                      <div className="col-xl-6" style={{ fontFamily: "serif", fontSize: "15px" }}>Revenue Uplift
                      </div>
                      <div className="col-xl-3 offset-xl-3">
                        <div style={{ paddingLeft: "33%", color: "red" }}>-3%
                        </div>
                      </div>
                    </div>
                    <div className='row'>
                      <div className="col-xl-8" style={{ fontFamily: "serif", fontSize: "15px" }}>Cost Saving
                      </div>
                      <div className="col-xl-4">
                        <div style={{ paddingLeft: "20%", color: "red" }}>-59700$
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-4">
                <div className="card">
                  <div className="card card" style={{ padding: '5%', paddingTop: '5%' }}>
                    <h5 className="text-black">
                      <strong>Program E</strong>
                      <span className="dot float-right" style={{ height: '25px', width: '25px', backgroundColor: "green", borderRadius: '50%', color: "green", display: "inline-block" }}>a</span>
                    </h5>
                    <div className="mb-5">
                      <ChartistGraph
                        className="height-150"
                        data={stackedBarData}
                        options={stackedBarOptions}
                        type="Bar"
                      />
                    </div>
                    <div className='row'>
                      <div className="col-xl-4" style={{ fontFamily: "serif", fontSize: "15px" }}>NPS Score
                      </div>
                      <div className="col-xl-3 offset-xl-5">
                        <div style={{ paddingLeft: "34%", color: "green" }}>20%
                        </div>
                      </div>
                    </div>
                    <div className='row'>
                      <div className="col-xl-6" style={{ fontFamily: "serif", fontSize: "15px" }}>Revenue Uplift
                      </div>
                      <div className="col-xl-3 offset-xl-3">
                        <div style={{ paddingLeft: "16%", color: "red" }}>-0.8%
                        </div>
                      </div>
                    </div>
                    <div className='row'>
                      <div className="col-xl-8" style={{ fontFamily: "serif", fontSize: "15px" }}>Cost Saving
                      </div>
                      <div className="col-xl-4">
                        <div style={{ paddingLeft: "9%", color: "green" }}>1398000$
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-xl-4">
                <div className="card">
                  <div className="card card" style={{ padding: '5%', paddingTop: '5%' }}>
                    <h5 className="text-black">
                      <strong>Program F</strong>
                      <span className="dot float-right" style={{ height: '25px', width: '25px', backgroundColor: " #00FF00", borderRadius: '50%', color: "#00FF00", display: "inline-block" }}>a</span>
                    </h5>
                    <div className="mb-5">
                      <ChartistGraph
                        className="height-150"
                        data={stackedBarData}
                        options={stackedBarOptions}
                        type="Bar"
                      />
                    </div>
                    <div className='row'>
                      <div className="col-xl-4" style={{ fontFamily: "serif", fontSize: "15px" }}>NPS Score
                      </div>
                      <div className="col-xl-3 offset-xl-5">
                        <div style={{ paddingLeft: "34%", color: "green" }}>18%
                        </div>
                      </div>
                    </div>
                    <div className='row'>
                      <div className="col-xl-6" style={{ fontFamily: "serif", fontSize: "15px" }}>Revenue Uplift
                      </div>
                      <div className="col-xl-3 offset-xl-3">
                        <div style={{ paddingLeft: "46%", color: "green" }}>9%
                        </div>
                      </div>
                    </div>
                    <div className='row'>
                      <div className="col-xl-8" style={{ fontFamily: "serif", fontSize: "15px" }}>Cost Saving
                      </div>
                      <div className="col-xl-4">
                        <div style={{ paddingLeft: "17%", color: "green" }}>170000$
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Authorize>
        )
    }

}
export default FunctionalCostBenefit