import React from 'react'
import { Helmet } from 'react-helmet'
import Authorize from 'components/LayoutComponents/Authorize'
import ChartCard from 'components/CleanUIComponents/ChartCard'
import { Chart } from "react-google-charts";


class OverallSpendView extends React.Component {


  render() {

    const data = [
      ["Day", "", "", "", ""],
      ["Mon", 0, 0, 22, 45],
      ["Tue", 31, 38, 55, 66],
      ["Wed", 50, 55, 77, 80],
      ["Thu", 77, 77, 66, 50],
      ["Fri", 68, 66, 22, 15]
    ];
    const options = {
      legend: "none",
      bar: { groupWidth: "50%" }, // Remove space between bars.
      candlestick: {
        fallingColor: { strokeWidth: 0, fill: "#add8e6" }, // red
        risingColor: { strokeWidth: 0, fill: "#0000FF" } // green
      }
    };
    return (
      <Authorize roles={['admin']} redirect to="/dashboard/beta">
        <Helmet title="Dashboard Alpha" />
        <div className='row'>
          <div className="col-xl-4">
            <ChartCard
              title="Total Projects"
              amount="354"
              chartProps={{
                width: 120,
                height: 107,
                lines: [
                  {
                    values: [2, 11, 8, 14, 18, 20, 26],
                    colors: {
                      area: 'rgba(199, 228, 255, 0.5)',
                      line: 'blue',
                    },
                  },
                ],
              }}
            />
          </div>
          <div className="col-xl-4">
            <ChartCard
              title="Total Capex"
              amount="$38.24 M"
              chartProps={{
                width: 120,
                height: 107,
                lines: [
                  {
                    values: [2, 11, 8, 14, 18, 20, 26],
                    colors: {
                      area: 'rgba(199, 228, 255, 0.5)',
                      line: 'blue',
                    },
                  },
                ],
              }}
            />
          </div>
          <div className="col-xl-4">
            <ChartCard
              title="Total Opex"
              amount="$4.9 M"
              chartProps={{
                width: 120,
                height: 107,
                lines: [
                  {
                    values: [2, 11, 8, 14, 18, 20, 26],
                    colors: {
                      area: 'rgba(199, 228, 255, 0.5)',
                      line: 'blue',
                    },
                  },
                ],
              }}
            />
          </div>
          <div className="col-xl-6">
            <div className="my-pretty-chart-container">
              <Chart
                chartType="CandlestickChart"
                width="100%"
                height="400px"
                data={data}
                options={options}
              />
            </div>
          </div>
          <div className="col-xl-6">
            <div className="my-pretty-chart-container">
              <Chart
                chartType="CandlestickChart"
                width="100%"
                height="400px"
                data={data}
                options={options}
              />
            </div>
          </div>

        </div>
        <div className="row">
          &nbsp;
        </div>
        <div className='row'>
          <div className="col-xl-6">
            <div className="my-pretty-chart-container">
              <div>
                {/* <div>s
                </div> */}
                <Chart
                  chartType="CandlestickChart"
                  width="100%"
                  height="400px"
                  data={data}
                  options={options}
                />
              </div>
            </div>
          </div>
          <div className="col-xl-6">
            <div className="my-pretty-chart-container">
              <Chart
                chartType="CandlestickChart"
                width="100%"
                height="400px"
                data={data}
                options={options}
              />
            </div>
          </div>

        </div>
      </Authorize>
    )
  }
}

export default OverallSpendView
